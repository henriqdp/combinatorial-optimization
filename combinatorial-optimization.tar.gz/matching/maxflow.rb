class Graphmatch::Maxflow
  #returns a hash with keys being the persons and values being the committees
  def self.best_matching!(graph, search, source = :source, sink = :sink)
    loop do
      path = augmenting_path graph, search
      break unless path
      augment_flow_graph! graph, path
    end
    matching_in graph, source, sink
  end

  # Finds an augmenting path in a flow graph.
  #
  # Returns the path from source to sink, as an array of edge arrays, for
  # example [[:source, 'a'], ['a', 'c'], ['c', :sink]]
  #
  # Search parameter will switch it from a max-flow to min-cost max-flow search
  def self.augmenting_path(graph, search = :shortest_path, source = :source, sink = :sink)
    if search == :shortest_path
      parents = Graphmatch::BFS.search graph, source, sink
    elsif search == :min_cost
      distance, parents = Graphmatch::BellmanFord.search graph, source
    end

    return nil unless parents[sink]

    # Reconstruct the path.
    path = []
    current_vertex = sink
    until current_vertex == source
      path << [parents[current_vertex], current_vertex]
      current_vertex = parents[current_vertex]

      if path.length > parents.length
        raise "Cannot terminate. Use integral edge weights."
      end
    end
    path.reverse!
  end

  # Augments a flow graph along a path.
  def self.augment_flow_graph!(graph, path)
    # Turn normal edges into residual edges and viceversa.
    edges = graph[:edges]
    path.each do |u, v|
      edges[v] ||= {}
      edges[v][u] = -edges[u][v]
      edges[u].delete v
    end
  end

  # The matching currently found in a matching graph.
  # @return [Hash] assignment hash of left_vertices => right_vertices
  def self.matching_in(graph, source = :source, sink = :sink)
    Hash[*((graph[:edges][sink] || {}).keys.map { |matched_vertex|
      [graph[:edges][matched_vertex].keys.first, matched_vertex]
    }.flatten)]
  end
end

require './matching/bellman-ford.rb'
require './matching/bfs.rb'
